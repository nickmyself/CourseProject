<?php // login_yourlastname.php   make sure to place in personal folder

$db_hostname = 'studentweb.comminfo.rutgers.edu';
$db_database = 'class-2014-1-17-610-557-01_jz337';
$db_username = 'jz337';
$db_password = 'oiC#V!5zenha';
/*
$db_hostname = 'localhost';
$db_database = 'class-2014-1-17-610-557-01_jz337';
$db_username = 'root';
$db_password = 'iamnick42';
*/
?>
