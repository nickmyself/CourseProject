## first put this in the  /mnt/space/www/studentweb.comminfo.rutgers.edu/htdocs/class-2014-1-17-610-557-01/bp291

## index.html
the HTML Form. Here it uses the radio button and text field to allow users search by name, director or language. The choice of the attribute chosen and text input value
will be passed to result.php file. 

## result.php
1. get the data pass from index.html
2. connect to school database with login_jz337.php
3. connect to database

