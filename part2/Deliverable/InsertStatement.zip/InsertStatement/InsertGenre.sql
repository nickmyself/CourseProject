/*
-- Query: SELECT * FROM `class-2014-1-17-610-557-01_jz337`.GENRE
LIMIT 0, 10000

-- Date: 2014-04-08 16:03
*/
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (12,'Adventure');
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (14,'Fantasy');
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (16,'Animation');
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (18,'Drama');
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (22,'Musical');
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (27,'Horror');
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (28,'Action');
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (35,'Comedy');
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (36,'History');
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (37,'Western');
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (53,'Thriller');
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (80,'Crime');
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (82,'Eastern');
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (99,'Documentary');
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (105,'Disaster');
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (878,'Science Fiction');
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (1115,'Road Movie');
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (2916,'Erotic');
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (9648,'Mystery');
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (9805,'Sport');
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (10402,'Music');
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (10595,'Holiday');
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (10748,'Suspense');
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (10749,'Romance');
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (10750,'Fan Film');
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (10751,'Family');
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (10752,'War');
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (10753,'Film Noir');
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (10754,'Neo-noir');
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (10755,'Short');
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (10756,'Indie');
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (10757,'Sports Film');
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (10758,'Sporting Event');
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (10769,'Foreign');
INSERT INTO `GENRE` (`GenreID`,`GenreName`) VALUES (10770,'TV movie');
